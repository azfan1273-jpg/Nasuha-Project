import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/settings_provider.dart';
import 'kasir_home_screen.dart';
import 'order_status_screen.dart';
import 'get_order_screen.dart';

import 'owner_screen.dart';
import 'kasir_screen.dart';
import 'edit_layanan_screen.dart';
import 'parfum_screen.dart';
import 'cari_pelanggan_screen.dart';
import 'printer_screen.dart';
import 'report_screen.dart';
import 'customer_insight_screen.dart';
import '../providers/order_provider.dart';
import '../helpers/database_helper.dart';
import 'discount_screen.dart';
import 'login_screen.dart';
 
import 'aa_pengumuman_developer.dart';
import '../helpers/notification_helper.dart';




class KasirPageManager extends StatefulWidget {
  const KasirPageManager({Key? key}) : super(key: key);

  @override
  State<KasirPageManager> createState() => _KasirPageManagerState();
}

class _KasirPageManagerState extends State<KasirPageManager> {
  late PageController _pageController;
  int _currentIndex = 0;
  final GlobalKey<KasirHomeScreenState> _kasirHomeKey = GlobalKey<KasirHomeScreenState>();

  // Kunci khusus untuk mengontrol Scaffold utama agar drawer tidak freeze
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // State untuk Broadcast Announcement dari Developer
  Map<String, dynamic>? _announcement;

// initstate untuk notification hp order pesanan baru
  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
    
    // Init Notifikasi
    NotificationHelper.init();
  
    // Listener Realtime untuk Notifikasi
    Supabase.instance.client
        .from('online_orders')
        .stream(primaryKey: ['id'])
        .eq('status', 'PENDING')
        .listen((data) {
      // Cek kalau ada data baru masuk
      if (data.isNotEmpty) {
        final latestOrder = data.first;
        NotificationHelper.showNewOrderNotification(
          customerName: latestOrder['customer_name'] ?? 'Pelanggan',
          serviceName: latestOrder['service_name'] ?? 'Layanan',
        );
      }
    });
  
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (mounted) {
        await context.read<SettingsProvider>().fetchStoreId();
        _fetchDeveloperAnnouncement();
        _kasirHomeKey.currentState?.refreshData();
      }
    });
  }

 Future<void> _fetchDeveloperAnnouncement() async {
      try {
        final List<dynamic> res = await Supabase.instance.client
            .from('app_announcements')
            .select()
            .eq('is_active', true)
            .order('created_at', ascending: false)
            .limit(1);
  
        if (mounted && res.isNotEmpty) {
          setState(() {
            _announcement = res.first as Map<String, dynamic>;
          });
        }
      } catch (e) {
        debugPrint('Error Pengumuman: $e');
      }
    }

  Future<void> _openAnnouncementUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    final currentUser = Supabase.instance.client.auth.currentUser;
    final String emailReal = currentUser?.email ?? 'Belum Login';

    final String namaTokoReal = settings.namaToko.isEmpty
        ? 'Nama Toko'
        : settings.namaToko;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: settings.bgDark,
      drawer: _buildCustomSidebar(context, settings, emailReal, namaTokoReal),      

      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 6),

            // HEADER TOKO
            _buildTokoHeader(
              namaToko: namaTokoReal,
              userRole: settings.userRole,
              emailToko: emailReal,
              settings: settings,
              onRefresh: () {
                _kasirHomeKey.currentState?.refreshData();
                _fetchDeveloperAnnouncement();
              },
            ),
            const SizedBox(height: 6),

            // BANNER PENGUMUMAN
            if (_announcement != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: _buildBannerAnnouncement(settings),
              ),
            const SizedBox(height: 8),

            // TAB BAR NAVIGASI
           Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _buildTabButton(0, 'Beranda', Icons.home_rounded, settings.accentColor),
                  const SizedBox(width: 6),
                  _buildTabButton(1, 'Order', Icons.bar_chart_rounded, settings.accentColor),
                  const SizedBox(width: 6),
                  _buildTabButton(2, 'Pesanan Masuk', Icons.inbox_rounded, settings.accentColor),
                ],
              ),
            ),
            const SizedBox(height: 6),

            // HALAMAN UTAMA
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: _onPageChanged,
                children: [
                  Material(
                    color: Colors.transparent,
                    child: KasirHomeScreen(key: _kasirHomeKey),
                  ),
                  const Material(
                    color: Colors.transparent,
                    child: OrderStatusScreen(),
                  ),
                  const Material(
                    color: Colors.transparent,
                    child: GetOrderScreen(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBannerAnnouncement(SettingsProvider settings) {
    final title = _announcement?['title'] ?? 'Pengumuman Aplikasi';
    final subtitle = _announcement?['subtitle'] ?? 'Klik untuk info selengkapnya';
    final linkUrl = _announcement?['link_url'] ?? '';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: linkUrl.isNotEmpty ? () => _openAnnouncementUrl(linkUrl) : null,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: settings.cardDark,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                    Icon(Icons.campaign_outlined, color: settings.accentColor, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // 🟢 GANTI DENGAN MARQUEETEXT AGAR TITLE BERJALAN
                          MarqueeText(
                            text: title,
                            velocity: 25.0,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: settings.accentColor,
                            ),
                          ),
                          const SizedBox(height: 1),
                          Text(
                            subtitle,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 8.5,
                              color: settings.textColor.withOpacity(0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: settings.accentColor,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: const Row(
                  children: [
                    Text(
                      'INFO',
                      style: TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    SizedBox(width: 2),
                    Icon(Icons.open_in_new_rounded, size: 9, color: Colors.white),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTokoHeader({
    required String namaToko,
    required String userRole,
    required String emailToko,
    required SettingsProvider settings,
    required VoidCallback onRefresh,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: settings.selectedTheme == 'gold'
              ? [const Color(0xFF2C2C2E), const Color(0xFF1E1E22)]
              : [const Color(0xFFFFF59D), const Color(0xFFF8BBD0)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    _scaffoldKey.currentState?.openDrawer();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: settings.selectedTheme == 'gold'
                          ? const Color(0xFF121212)
                          : const Color(0xFFFCE7F3),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.storefront_rounded, color: settings.accentColor, size: 20),
                  ),
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: Text(
                              namaToko,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: settings.selectedTheme == 'gold' ? Colors.white : const Color(0xFF111827),
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: settings.accentColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              userRole.isEmpty ? 'KASIR' : userRole.toUpperCase(),
                              style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        emailToko,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: settings.selectedTheme == 'gold' ? Colors.grey[400] : Colors.grey[700],
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(
              Icons.refresh_rounded,
              color: settings.selectedTheme == 'gold' ? Colors.white : const Color(0xFF111827),
            ),
            onPressed: onRefresh,
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String title, IconData icon, Color activeColor) {
    final isSelected = _currentIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: () {
          setState(() {
            _currentIndex = index;
            _pageController.animateToPage(
              index,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
            );
          });
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? activeColor.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Icon(icon, size: 18, color: isSelected ? activeColor : Colors.grey),
              const SizedBox(width: 6),
              Text(
                title,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? activeColor : Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // SIDEBAR DRAWER YANG AMAN & BERSIH
  Widget _buildCustomSidebar(BuildContext context, SettingsProvider settings, String email, String namaToko) {
    return Drawer(
      backgroundColor: settings.cardDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(topRight: Radius.circular(24), bottomRight: Radius.circular(24)),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // HEADER PROFIL DALAM SIDEBAR
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: settings.bgDark,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))],
                    ),
                    child: Icon(Icons.storefront_rounded, color: settings.accentColor, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                namaToko,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: settings.textColor),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(color: settings.accentColor, borderRadius: BorderRadius.circular(12)),
                              child: Text(
                                settings.userRole.isEmpty ? 'KASIR' : settings.userRole.toUpperCase(),
                                style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(email, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: settings.textColor.withOpacity(0.6))),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: settings.textColor.withOpacity(0.1), indent: 16, endIndent: 16),
            
            // LIST MENU UTAMA DENGAN PEMBATASAN ROLE
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                children: [
                  _buildSidebarItem(
                    icon: Icons.person_outline_rounded,
                    title: 'Profil',
                    settings: settings,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const OwnerScreen()));
                    },
                  ),

                  // MENU KHUSUS OWNER
                  if (settings.userRole == 'owner') ...[
                    _buildSidebarItem(
                      icon: Icons.badge_outlined,
                      title: 'Kelola Pegawai',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const KasirScreen()));
                      },
                    ),
                    _buildSidebarItem(
                      icon: Icons.local_laundry_service_outlined,
                      title: 'Daftar Layanan',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => EditLayananScreen()));
                      },
                    ),
                    _buildSidebarItem(
                      icon: Icons.groups_outlined,
                      title: 'Daftar Pelanggan',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CariPelangganScreen(isSelectionMode: false)));
                      },
                    ),
                    _buildSidebarItem(
                      icon: Icons.opacity_outlined,
                      title: 'Daftar Parfum',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ParfumScreen()));
                      },
                    ),
                    _buildSidebarItem(
                      icon: Icons.confirmation_number_outlined,
                      title: 'Pengaturan Diskon',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const DiscountScreen()));
                      },
                    ),
                  ],

                  _buildSectionDivider(settings),

                  _buildSidebarItem(
                    icon: Icons.print_outlined,
                    title: 'Printer & Nota',
                    settings: settings,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const PrinterScreen()));
                    },
                  ),

                  // LAPORAN KEUANGAN KHUSUS OWNER
                  if (settings.userRole == 'owner') ...[
                    _buildSectionDivider(settings),
                    _buildSidebarItem(
                      icon: Icons.bar_chart_rounded,
                      title: 'Laporan Keuangan',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const ReportScreen()));
                      },
                    ),
                    _buildSidebarItem(
                      icon: Icons.analytics_outlined,
                      title: 'Analisis Pelanggan',
                      settings: settings,
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const CustomerInsightScreen()));
                      },
                    ),
                  ],

                  _buildSectionDivider(settings),

                  // PEMILIH TEMA
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Theme',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: settings.textColor.withOpacity(0.6),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            InkWell(
                              onTap: () => context.read<SettingsProvider>().setTheme('default'),
                              borderRadius: BorderRadius.circular(8),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                child: Row(
                                  children: [
                                    Icon(
                                      settings.selectedTheme == 'default'
                                          ? Icons.radio_button_checked
                                          : Icons.radio_button_off,
                                      size: 16,
                                      color: const Color(0xFFEC4899),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      'Pink',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: settings.textColor,
                                        fontWeight: settings.selectedTheme == 'default'
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 16),
                            InkWell(
                              onTap: () => context.read<SettingsProvider>().setTheme('gold'),
                              borderRadius: BorderRadius.circular(8),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                child: Row(
                                  children: [
                                    Icon(
                                      settings.selectedTheme == 'gold'
                                          ? Icons.radio_button_checked
                                          : Icons.radio_button_off,
                                      size: 16,
                                      color: settings.selectedTheme == 'gold'
                                          ? const Color(0xFFFFD700)
                                          : Colors.grey,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      'Black',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: settings.textColor,
                                        fontWeight: settings.selectedTheme == 'gold'
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  _buildSectionDivider(settings),

                  _buildSidebarItem(
                    icon: Icons.workspace_premium_outlined,
                    title: 'Premium Akun',
                    settings: settings,
                    onTap: () => Navigator.pop(context),
                  ),
                  _buildSidebarItem(
                    icon: Icons.info_outline_rounded,
                    title: 'About Us',
                    settings: settings,
                    onTap: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: settings.textColor.withOpacity(0.1)),
            
            // TOMBOL LOGOUT DI BAWAH
            Padding(
              padding: const EdgeInsets.all(12),
              child: _buildSidebarItem(
                icon: Icons.logout_rounded,
                title: 'LogOut Akun',
                settings: settings,
                textColor: Colors.redAccent,
                iconColor: Colors.redAccent,
                onTap: () async {
                  final navigator = Navigator.of(context);
                  navigator.pop();

                  showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => PopScope(
                      canPop: false,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: settings.accentColor,
                        ),
                      ),
                    ),
                  );

                  try {
                    if (context.mounted) {
                      context.read<SettingsProvider>().clearSettings();
                      context.read<OrderProvider>().clearState();
                    }
                  } catch (e) {
                    debugPrint('Error clear provider: $e');
                  }

                  try {
                    await DatabaseHelper.instance.clearLocalOrders();
                  } catch (e) {
                    debugPrint('Error clear local DB: $e');
                  }

                  try {
                    await Supabase.instance.client.auth.signOut();
                  } catch (e) {
                    debugPrint('Error sign out: $e');
                  }

                  navigator.pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false,
                  );
                },                             
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebarItem({
    required IconData icon,
    required String title,
    required SettingsProvider settings,
    required VoidCallback onTap,
    Color? textColor,
    Color? iconColor,
  }) {
    final finalTextColor = textColor ?? settings.textColor;
    final finalIconColor = iconColor ?? settings.textColor.withOpacity(0.7);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: ListTile(
          dense: true,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          horizontalTitleGap: 12,
          leading: Icon(icon, color: finalIconColor, size: 20),
          title: Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: finalTextColor)),
          onTap: onTap,
        ),
      ),
    );
  }

  Widget _buildSectionDivider(SettingsProvider settings) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Divider(height: 1, color: settings.textColor.withOpacity(0.1)),
    );
  }
}
